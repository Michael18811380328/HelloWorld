# 基本命令

## 建立新项目

```
$ vue init webpack my_blog
```

## 安装所有的第三方包

```
$ npm install
```

## 在本地运行

```
$ npm run dev
```

## 部署

```
$ npm run build
```

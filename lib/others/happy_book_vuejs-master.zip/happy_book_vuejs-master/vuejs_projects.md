# 用到Vuejs的项目

参考知乎： https://www.zhihu.com/question/33264609?sort=created

- 滴滴, 还出了一本书: Vue.js 权威指南.

- 饿了么，开源了一个基于Vue的UI库(https://github.com/ElemeFE/element)

- 阿里的 weex  (https://github.com/alibaba/weex)

- GitLab https://about.gitlab.com/2016/10/20/why-we-chose-vue/

- 大疆

- facebook:  https://newsfeed.fb.com/welcome-to-news-feed?lang=en

- 新浪微博

更全列表，见：https://github.com/vuejs/awesome-vue#projects-using-vuejs

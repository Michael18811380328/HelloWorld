# Vue项目的演示

本项目基于Webpack .

本项目的文字版教程,见:

- 在线浏览： http://vue_book.siwei.me/
- 教程源代码：http://github.com/sg552/happy_book_vuejs

## 安装方式:

npm: 3.10.8 (npm > 3.0)

node: v6.9.1 (node > 6.0)

vue: 2.0+

具体见教程.


## 运行

$ npm run dev

## 在线Demo

http://vue_demo.siwei.me/#/

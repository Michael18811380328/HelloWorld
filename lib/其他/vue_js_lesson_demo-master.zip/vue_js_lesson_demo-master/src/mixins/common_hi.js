export default {
  methods: {
    hi: function(name){
      return "你好, " + name;
    }
  }
}

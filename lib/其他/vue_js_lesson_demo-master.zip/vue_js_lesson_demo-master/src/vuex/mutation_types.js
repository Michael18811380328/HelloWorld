// 大家做项目的时候, 要统一把 mutation type定义在这里.
// 类似于一个 方法列表.
export const COUNT_DOWN = 'COUNT_DOWN'
export const INCREASE = 'INCREASE'

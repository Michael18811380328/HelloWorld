<template>
  <div id="app">
    <!--
    <img src="./assets/logo.png" style='width: 100px; height: 100px;
    border: 1px solid red;
    '>
    -->
    <!-- 所有的动态页面，都在这里 -->
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'app'
}
</script>

<style>
</style>

<template>
  <div>
    {{message}}
  </div>
</template>

<script>
export default {
  data () {
    return {
      message: '你好Vue! 本消息来自于变量'
    }
  }
}
</script>

<style>
</style>

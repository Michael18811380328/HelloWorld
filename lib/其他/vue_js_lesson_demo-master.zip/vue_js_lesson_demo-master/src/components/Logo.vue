<template>
  <div class='logo'>
    <h1>{{title}}</h1>
    <img src='http://siweitech.b0.upaiyun.com//image/570/siwei.me_header.png'/>
  </div>
</template>

<script>
export default {
  props: ['title'],
}
</script>
